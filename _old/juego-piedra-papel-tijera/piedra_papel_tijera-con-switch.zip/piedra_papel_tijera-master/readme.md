# Piedra, papel o tijera.

Esta implementado en javaScript. Su ejecución se realiza por la consola del navegador.
