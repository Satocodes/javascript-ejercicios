var productos = [
    {
        nombre: "harina",
        precio: 35
    },
    {
        nombre: "pan",
        precio: 25
    },
    {
        nombre: "papa",
        precio: 52
    },
    {
        nombre: "palta",
        precio: 55
    },
    {
        nombre: "fideos",
        precio: 85
    },
    {
        nombre: "aceite",
        precio: 350
    },
    {
        nombre: "sopa",
        precio: 86
    },
    {
        nombre: "mermelada",
        precio: 108
    },
    {
        nombre: "porotos",
        precio: 69
    },
    {
        nombre: "lentejas",
        precio: 85
    },
    {
        nombre: "mandarina",
        precio: 43
    },
    {
        nombre: "banana",
        precio: 79
    },
    {
        nombre: "leche de almendras",
        precio: 145
    },
    {
        nombre: "papel higiénico",
        precio: 147
    },
    {
        nombre: "lavandina",
        precio: 55
    },
    {
        nombre: "alcohol en gel",
        precio: 123
    },
    {
        nombre: "shampoo",
        precio: 400
    },
    {
        nombre: "arroz",
        precio: 66
    },
    {
        nombre: "harina",
        precio: 35
    },
    {
        nombre: "salsa de tomate",
        precio: 35
    },
];

var carrito = [];
var tabla   = document.getElementsByTagName("table")[0];

function clickBoton(event) {
    boton = event.target
    boton.disabled = true
    carrito.push(productos[boton.producto]) 
    console.log(carrito)
}

for (var i = 0; i < productos.length; i++) {
    var hilera = document.createElement("tr");

    var celda = document.createElement("td")
    var textoCelda = document.createTextNode(productos[i].nombre);
    celda.appendChild(textoCelda);
    hilera.appendChild(celda);

    celda = document.createElement("td")
    textoCelda = document.createTextNode(productos[i].precio);
    celda.appendChild(textoCelda);
    hilera.appendChild(celda);

    var boton = document.createElement("BUTTON")

    celda = document.createElement("td")
    boton.innerHTML = "agregar al carrito";
    boton.onclick = clickBoton
    boton.producto = i
    celda.appendChild(boton)
    hilera.appendChild(celda)
    
    tabla.appendChild(hilera);
}

// quiero listar los numeros que tengo en carrito para despues buscarlos en productos
function comprar() {
    
    var lista = document.getElementsByTagName("ul")[0]

    for (let index = 0; index < carrito.length; index++) {
        var fila = document.createElement("li") 
        var lineaFila = document.createTextNode(carrito[index].nombre + ' ')
        fila.appendChild(lineaFila)
        lista.appendChild(fila)

        lineaFila = document.createTextNode('$ '+ carrito[index].precio)
        fila.appendChild(lineaFila)
        lista.appendChild(fila)
    }
totalAPagar();
}


function totalAPagar() {
    console.log("hola")
    var lista = document.getElementById("total")
    var sum = 0

    for (let index = 0; index < carrito.length; index++) {
                 sum = sum + carrito[index].precio
            }
console.log(sum);
lista.innerHTML = '$ ' + sum
};